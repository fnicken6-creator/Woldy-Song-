const filesInput=document.getElementById('audioFiles'), tracksEl=document.getElementById('tracks'), empty=document.getElementById('empty'), search=document.getElementById('search'), filter=document.getElementById('filter'), audio=document.getElementById('audio');
let tracks=[], current=-1, urls=[], favorites=new Set();
const $=id=>document.getElementById(id);
function time(s){if(!Number.isFinite(s))return '0:00';return Math.floor(s/60)+':'+String(Math.floor(s%60)).padStart(2,'0')}
function niceName(n){return n.replace(/\.[^/.]+$/,'').replace(/[_-]+/g,' ').trim()}
function render(){let q=search.value.toLowerCase().trim(), mode=filter.value;let shown=tracks.map((t,i)=>({...t,i})).filter(t=>(t.name+' '+t.artist).toLowerCase().includes(q)&&(mode!=='fav'||favorites.has(t.i)));tracksEl.innerHTML='';shown.forEach(t=>{let row=document.createElement('div');row.className='track';row.innerHTML=`<div class="art">♫</div><div class="trackname"><strong></strong><small></small></div><button class="iconbtn fav ${favorites.has(t.i)?'active':''}" aria-label="Favori">${favorites.has(t.i)?'♥':'♡'}</button><button class="playnow">▶</button>`;row.querySelector('.trackname strong').textContent=t.name;row.querySelector('.trackname small').textContent=t.artist;row.querySelector('.fav').onclick=()=>{favorites.has(t.i)?favorites.delete(t.i):favorites.add(t.i);render()};row.querySelector('.playnow').onclick=()=>play(t.i);row.querySelector('.art').onclick=()=>play(t.i);tracksEl.appendChild(row)});empty.classList.toggle('hidden',shown.length>0);$('count').textContent=tracks.length?`${tracks.length} morceau${tracks.length>1?'x':''}`:'Aucun morceau ajouté';}
function play(i){if(i<0||i>=tracks.length)return;current=i;audio.src=tracks[i].url;audio.play().catch(()=>{});$('player').classList.remove('hidden');$('nowTitle').textContent=tracks[i].name;$('nowArtist').textContent=tracks[i].artist;$('play').textContent='Ⅱ';}
filesInput.addEventListener('change',e=>{for(const f of e.target.files){if(!f.type.startsWith('audio/'))continue;const url=URL.createObjectURL(f);urls.push(url);tracks.push({name:niceName(f.name),artist:'Fichier sur mon téléphone',url})}render();if(tracks.length&&current===-1)play(tracks.length-1);filesInput.value=''});
$('addTop').onclick=$('addHero').onclick=()=>filesInput.click();search.addEventListener('input',render);filter.addEventListener('change',render);
$('play').onclick=()=>{if(current<0){if(tracks.length)play(0);return}if(audio.paused){audio.play();$('play').textContent='Ⅱ'}else{audio.pause();$('play').textContent='▶'}};
$('prev').onclick=()=>{if(tracks.length)play((current-1+tracks.length)%tracks.length)};$('next').onclick=()=>{if(tracks.length)play((current+1)%tracks.length)};
audio.addEventListener('timeupdate',()=>{$('elapsed').textContent=time(audio.currentTime);$('duration').textContent=time(audio.duration);$('seek').value=audio.duration?audio.currentTime/audio.duration*100:0});
$('seek').addEventListener('input',()=>{if(audio.duration)audio.currentTime=Number($('seek').value)/100*audio.duration});
audio.addEventListener('ended',()=>{if(tracks.length)play((current+1)%tracks.length)});
$('volumeBtn').onclick=()=>{audio.muted=!audio.muted;$('volumeBtn').textContent=audio.muted?'🔇':'🔊'};
if('serviceWorker' in navigator && location.protocol.startsWith('http'))navigator.serviceWorker.register('sw.js').catch(()=>{});
render();
// Découverte en ligne : résultats et extraits disponibles via l'API publique iTunes.
const onlineSection = document.getElementById('onlineSection');
const onlineTracks = document.getElementById('onlineTracks');
const onlineStatus = document.getElementById('onlineStatus');
let activeTab = 'local', onlineResults = [], onlineAudioUrl = null, onlineAudio = new Audio();
document.querySelectorAll('.tab').forEach(btn => btn.addEventListener('click', () => {
  activeTab = btn.dataset.tab;
  document.querySelectorAll('.tab').forEach(b => b.classList.toggle('active', b === btn));
  document.querySelector('.library').classList.toggle('hidden', activeTab !== 'local');
  onlineSection.classList.toggle('hidden', activeTab !== 'online');
  if (activeTab === 'online') search.placeholder = '⌕  Rechercher un titre, artiste ou style…';
  else search.placeholder = '⌕  Rechercher dans ma musique…';
}));
let onlineTimer;
search.addEventListener('input', () => {
  if (activeTab !== 'online') return;
  clearTimeout(onlineTimer);
  const term = search.value.trim();
  if (!term) { onlineStatus.textContent = 'Tape un titre, un artiste ou un style musical pour rechercher.'; onlineTracks.innerHTML=''; return; }
  onlineStatus.textContent = 'Recherche en cours…';
  onlineTimer = setTimeout(() => searchOnline(term), 450);
});
async function searchOnline(term) {
  try {
    const url = 'https://itunes.apple.com/search?media=music&entity=song&limit=25&term=' + encodeURIComponent(term);
    const res = await fetch(url);
    if (!res.ok) throw new Error('search');
    const data = await res.json();
    onlineResults = (data.results || []).filter(x => x.previewUrl);
    onlineTracks.innerHTML = '';
    onlineStatus.textContent = onlineResults.length ? `${onlineResults.length} résultat(s) avec extrait disponible.` : 'Aucun extrait trouvé pour cette recherche. Essaie un autre mot-clé.';
    onlineResults.forEach((item, i) => {
      const row = document.createElement('div'); row.className = 'track';
      const img = document.createElement('img'); img.className = 'online-cover'; img.src = item.artworkUrl100 || ''; img.alt = '';
      const meta = document.createElement('div'); meta.className = 'trackname';
      const title = document.createElement('strong'); title.textContent = item.trackName || 'Titre inconnu';
      const artist = document.createElement('small'); artist.textContent = (item.artistName || 'Artiste inconnu') + (item.collectionName ? ' · ' + item.collectionName : '');
      meta.append(title, artist);
      const listen = document.createElement('button'); listen.className='playnow'; listen.textContent='▶ Extrait';
      listen.onclick = () => playOnline(item, listen);
      const link = document.createElement('a'); link.className='open-link'; link.textContent='Plateforme'; link.href=item.trackViewUrl || item.artistViewUrl || 'https://music.apple.com/'; link.target='_blank'; link.rel='noopener noreferrer';
      row.append(img, meta, listen, link); onlineTracks.appendChild(row);
    });
  } catch (e) {
    onlineStatus.textContent = 'Impossible de charger les résultats maintenant. Vérifie ta connexion Internet puis réessaie.';
  }
}
function playOnline(item, button) {
  if (onlineAudioUrl) { onlineAudio.pause(); }
  onlineAudioUrl = item.previewUrl;
  onlineAudio.src = onlineAudioUrl;
  onlineAudio.play().then(() => { onlineStatus.textContent = 'Extrait en lecture : ' + item.trackName + ' — ' + item.artistName; }).catch(() => { onlineStatus.textContent = 'Appuie encore sur « Extrait » pour lancer la lecture.'; });
  document.querySelectorAll('#onlineTracks .playnow').forEach(b => b.textContent='▶ Extrait');
  button.textContent='Ⅱ En lecture';
  onlineAudio.onended = () => { button.textContent='▶ Extrait'; };
}
