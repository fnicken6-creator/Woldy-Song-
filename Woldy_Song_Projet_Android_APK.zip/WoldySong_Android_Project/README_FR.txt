WOLDY SONG — PROJET ANDROID (source)
====================================

Ce ZIP contient le projet source Android, pas un APK déjà compilé.

Pour générer l'APK :
1. Sur un ordinateur, installe Android Studio depuis le site officiel : https://developer.android.com/studio
2. Décompresse ce ZIP.
3. Dans Android Studio, choisis Open et sélectionne le dossier WoldySong_Android_Project.
4. Attends la synchronisation Gradle. Si Android Studio demande d'installer Android SDK Platform 35, accepte.
5. Menu Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Après la compilation, Android Studio indique un lien vers app-debug.apk.

Fonctions incluses :
- Interface Woldy Song embarquée dans l'application.
- Lecture de fichiers audio sélectionnés depuis le téléphone.
- Recherche de morceaux et extraits en ligne (connexion Internet requise).
- Les résultats en ligne et extraits dépendent du catalogue du service tiers.

Limites :
- Ce projet n'a pas été compilé ni testé sur un appareil réel dans cet environnement.
- Il n'inclut pas les droits d'accès à un catalogue complet de streaming commercial.
- Pour construire l'APK, un environnement Android/Gradle fonctionnel est nécessaire.
